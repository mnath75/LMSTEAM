export default function Courses() {
return(
    <>
        <h2 className={'text-center mt-3'}>Courses is coming soon..</h2>
        </>
)
}