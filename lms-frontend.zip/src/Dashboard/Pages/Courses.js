import React from 'react';
export default function Courses() {
    return(
        <>
            <h1>Courses</h1>
        </>
    )
}